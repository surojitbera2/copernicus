# OJS (Open Journal System) to Copernicus Citation Index xml export plugin
This plug-in allows to export article meta-data to Copernicus citation index in xml format with respect to official xml-schema

# Installation

1. Download latest release from release tab. Please choose correct version of OJS. OJS2 and OJS3 are both supported;
2. Open and open Plugin Management > Install A New Plugin;
3. Choose downloaded file;
4. Enjoy if it were works;

# Troubleshooting

1. If some gone wrong, please find folder "copernicus" in OJS_ROOT/plugins/importexport/ and delete it
